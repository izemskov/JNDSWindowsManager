package nds;

public class Bios {

    /**
     * Halts execution until the beginning of the next VBlank
     */
    public static native void swiWaitForVBlank();

}
