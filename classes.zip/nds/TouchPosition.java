package nds;

public class TouchPosition {
    public int x;
    public int y;
    public int px;
    public int py;
    public int z1;
    public int z2;

    public native void update();
}
