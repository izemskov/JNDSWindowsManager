package nds.pstros.video;

public class NDSRectangle {
	public int x;
	public int y;
	public int width;
	public int height;

	public NDSRectangle () {
	}

	public NDSRectangle (int x, int y, int w, int h) {
		this.x = x;
		this.y = y;
		this.width = w;
		this.height = h;
	}

}
